# WebAPICore
A sample repo for testing .net core app on openshift
